package com.example.testdatabasebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestdatabasebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestdatabasebackendApplication.class, args);
	}

}
