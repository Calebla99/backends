package com.example.testdatabasebackend;

import javax.persistence.Entity;
import java.sql.Timestamp;

@Entity

public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_uid")
    private Integer userUid;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "user_password")
    private String userPassword;

    @Column(name = "user_role")
    private String userRole;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "create_by")
    private String createdBy;

    @Column(name = "modified_at")
    private Timestamp modifiedAt;

    @Column(name = "modified_by")
    private String modifiedBy;

    // Constructors, getters, and setters
}

}


