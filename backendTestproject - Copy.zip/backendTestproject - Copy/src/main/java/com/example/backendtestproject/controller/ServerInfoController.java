package com.example.backendtestproject.controller;

import com.example.backendtestproject.model.ServerInfo;
import com.example.backendtestproject.repository.ServerInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
public class ServerInfoController {

    @Autowired
    private ServerInfoRepository serverInfoRepository;

    @PostMapping("/serverinfo")
    ServerInfo newServerInfo(@RequestBody ServerInfo newServerInfo) {
        return serverInfoRepository.save(newServerInfo);
    }

    @GetMapping("/serverinfos")
    List<ServerInfo> getAllServerInfo() {
        return serverInfoRepository.findAll();
    }
}