package com.example.backendtestproject.controller;

import com.example.backendtestproject.model.UserApps;
import com.example.backendtestproject.repository.UserAppsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
public class UserAppsController {

    @Autowired
    private UserAppsRepository userAppsRepository;

    @PostMapping("/userapp")
    UserApps newUserApps(@RequestBody UserApps newUserApps) {
        return userAppsRepository.save(newUserApps);
    }

    @GetMapping("/userapps")
    List<UserApps> getAllUserApps() {
        return userAppsRepository.findAll();
    }
}