package com.example.backendtestproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTestprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendTestprojectApplication.class, args);
    }

}


//46.54