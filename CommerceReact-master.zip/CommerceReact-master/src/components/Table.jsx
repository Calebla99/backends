import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Css/Table.css';

export const Table = () => {
  const [tableData, setTableData] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [searchInput, setSearchInput] = useState('');
  const [sortCriteria, setSortCriteria] = useState(null);
  const [filterCriteria, setFilterCriteria] = useState('all'); // Default filter criteria

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:8080/serverinfos');
      setTableData(response.data);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleRowClick = (row) => {
    setSelectedRow(row);
  };

  const handleSearchInputChange = (event) => {
    setSearchInput(event.target.value);
  };

  const handleSort = (criteria) => {
    setSortCriteria(criteria);
  };

  const handleFilterChange = (event) => {
    setFilterCriteria(event.target.value);
  };

  // Define filter options
  const filterOptions = [
    { label: 'All', value: 'all' },
    { label: 'Server UID', value: 'serverInfoUid' },
    { label: 'Application ID', value: 'appInfoUid' },
    { label: 'Source Hostname', value: 'sourceHostname' },
    { label: 'Source IP Address', value: 'sourceIpAddress' },
    { label: 'Destination Host Name', value: 'destinationHostName' },
    { label: 'Destination IP Address', value: 'destinationIpAddress' },
    { label: 'Destination Port', value: 'destinationPort' },
    { label: 'IP Status', value: 'ipStatus' },
    { label: 'Created At', value: 'createdAt' },
    { label: 'Created By', value: 'createdBy' },
    { label: 'Modified At', value: 'modifiedAt' },
    { label: 'Modified By', value: 'modifiedBy' },
  ];

  // Function to filter data based on search input and selected filter criteria
  const filteredData = tableData.filter((row) => {
    if (filterCriteria === 'all') {
      return Object.values(row).some((value) =>
          value.toString().toLowerCase().includes(searchInput.toLowerCase())
      );
    } else {
      return row[filterCriteria].toString().toLowerCase().includes(searchInput.toLowerCase());
    }
  });

  // Function to sort data based on sorting criteria
  const sortedData = sortCriteria
      ? filteredData.slice().sort((a, b) => {
        if (a[sortCriteria] < b[sortCriteria]) return -1;
        if (a[sortCriteria] > b[sortCriteria]) return 1;
        return 0;
      })
      : filteredData;

  return (
      <div className="tableContainer">
        <div className="searchContainer">
          <input
              type="text"
              placeholder="Search..."
              value={searchInput}
              onChange={handleSearchInputChange}
          />
          <select value={filterCriteria} onChange={handleFilterChange}>
            {filterOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
            ))}
          </select>
        </div>
        <table>
          <thead>
          <tr>
            <th onClick={() => handleSort('serverInfoUid')}>Server UID</th>
            <th onClick={() => handleSort('appInfoUid')}>App UID</th>
            <th onClick={() => handleSort('sourceHostname')}>Src. Host Name</th>
            <th onClick={() => handleSort('sourceIpAddress')}>Src. IP</th>
            <th onClick={() => handleSort('destinationHostName')}>Dest. Host Name</th>
            <th onClick={() => handleSort('destinationIpAddress')}>Dest. IP</th>
            <th onClick={() => handleSort('port')}>Port #</th>
            <th onClick={() => handleSort('ipStatus')}>Status</th>
            <th onClick={() => handleSort('createdAt')}>Created At</th>
            <th onClick={() => handleSort('createdBy')}>Created By</th>
            <th onClick={() => handleSort('modifiedAt')}>Date Modified</th>
            <th onClick={() => handleSort('modifiedBy')}>Modified By</th>
          </tr>
          </thead>
          <tbody>
          {sortedData.map((row, index) => (
              <tr
                  key={index}
                  className={row === selectedRow ? 'selected' : ''}
                  onClick={() => handleRowClick(row)}
              >
                <td>{row.serverInfoUid}</td>
                <td>{row.appInfoUid}</td>
                <td>{row.sourceHostname}</td>
                <td>{row.sourceIpAddress}</td>
                <td>{row.destinationHostName}</td>
                <td>{row.destinationIpAddress}</td>
                <td>{row.destinationPort}</td>
                <td>{row.ipStatus}</td>
                <td>{row.createdAt}</td>
                <td>{row.createdBy}</td>
                <td>{row.modifiedAt}</td>
                <td>{row.modifiedBy}</td>
              </tr>
          ))}
          </tbody>
        </table>
      </div>
  );
};