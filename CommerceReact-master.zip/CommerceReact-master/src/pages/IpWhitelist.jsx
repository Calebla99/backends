import { useState } from 'react'
import {Table} from '../components/Table'
import { Nav } from '../components/Nav'

export const IpWhitelist = () => {
    return (
        <>
            <Nav />
            <Table />
        </>
      )
};